# Rustyfin Setup Wizard — Implementation Progress Tracker
Generated: 2026-02-13  
Purpose: This file is the single place to track **what’s done vs what remains** while implementing the Rustyfin first‑run setup wizard.

This tracker is meant for an AI implementer **and** humans. It is intentionally “procedural”: it lists tasks in dependency order, with explicit file touchpoints and acceptance criteria.

---

## 0) Canonical input artifacts (read these first)

**Source of truth (do not diverge without updating the spec + OpenAPI):**
1) `Rustyfin_Setup_Wizard_Spec_v4_OpenAPI_Sequence.md` — full endpoint behavior + sequence diagrams  
2) `rustyfin-setup-wizard.openapi.yaml` — typed contract (schemas + errors + examples)

**Useful context / earlier drafts (do not implement from these if they conflict with v4):**
- `Rustyfin_Setup_Wizard_Spec_v3_No_Imagination.md`
- `Rustyfin_Setup_Wizard_Spec_v2.md`
- `Rustyfin_Jellyfin_Setup_Wizard_Deep_Dive.docx`

---

## 1) Non‑negotiable constraints

### 1.1 Product constraints
- **No “login wall” on fresh install.** If setup is incomplete, the UI MUST route to `/setup`.
- **No default admin creation at boot.** Remove the current `RUSTFIN_ADMIN_PASSWORD` / `"admin"` bootstrap behavior.
- **Mirror Jellyfin’s first‑run flow** (language → server defaults → create admin → optional libraries → metadata defaults → networking → complete).
- **Setup mode is hardened.** Setup write endpoints MUST be protected (owner token + local/remote policy + rate limiting + safe logging).
- **After completion, setup endpoints are admin‑only** (except public info).

### 1.2 Engineering constraints
- Backend is Rust (Axum + Tower). Rate limiting MUST be implementable cleanly as a **Tower layer**.
- Keep the existing architectural style: modular monolith, SQLite via `sqlx`, JWT auth.
- Avoid adding new “system binaries” as dependencies or workarounds.
- All network/API behavior MUST match the OpenAPI YAML.

---

## 2) Repo touchpoints (where code MUST change)

These paths exist in the current Rustyfin tree (from `Rustyfin.zip`). The implementer should modify/create files here.

### 2.1 Backend (Rust)

**Existing files to modify**
- `crates/server/src/main.rs`
  - Remove “bootstrap admin” logic (currently creates admin with default password).
- `crates/server/src/routes.rs`
  - Add:
    - `GET /api/v1/system/info/public`
    - Nest `/api/v1/setup/*` router
- `crates/core/src/error.rs`
  - Expand error model to support `422` validation and `429` rate limiting (plus structured `details`).

**New server modules (recommended)**
- `crates/server/src/setup/mod.rs` (or `setup.rs`) — setup router + handlers
- `crates/server/src/setup/guard.rs` — `SetupWriteGuard` extractor/middleware helpers
- `crates/server/src/setup/validation.rs` — password/username/locale/path validation helpers
- `crates/server/src/setup/state_machine.rs` — setup state enums + prerequisite checks

**DB layer**
- `crates/db/migrations/003_settings_and_setup.sql` — settings + setup session + idempotency tables
- `crates/db/src/repo/settings.rs` — typed settings get/set
- `crates/db/src/repo/setup_session.rs` — claim/release/refresh/purge
- `crates/db/src/repo/idempotency.rs` — idempotency key storage (if not embedded in setup module)
- `crates/db/src/repo/mod.rs` — export new repos
- `crates/db/src/migrate.rs` — ensure migration order works

**Existing tests to update**
- `crates/server/tests/integration.rs`
  - Currently bootstraps an admin user manually; update to cover setup mode behavior.

### 2.2 Frontend (Next.js)

**Existing files to modify**
- `ui/src/lib/api.ts`
  - Add “public fetch” helpers that do NOT auto-redirect to `/login` during setup.
- `ui/src/app/page.tsx` and/or route middleware
  - Add the “setup guard” based on `/api/v1/system/info/public`.

**New UI routes**
- `ui/src/app/setup/page.tsx` (wizard container)
- `ui/src/app/setup/*` (step components)
- Optional: `ui/src/app/setup/layout.tsx` to remove normal app chrome

---

## 3) Implementation order (dependency graph)

The fastest safe path is:

1) **DB + core error model**
2) **Public system info**
3) **Setup session + guard + rate limiting**
4) **Setup endpoints (in contract order)**
5) **UI wizard + routing guard**
6) **Tests (unit + integration + e2e)**
7) **Hardening pass (logging, remote setup token, proxy/IP rules, edge cases)**

Do NOT start on the UI wizard screens until:
- `/api/v1/system/info/public` is implemented, AND
- `/api/v1/setup/session/claim` works, AND
- setup write endpoints are guarded + rate limited.

---

## 4) Progress ledger (keep this updated)

When you complete a task, mark it ✅ and add a commit hash/PR link.

| Area | Task | Status | PR / Commit | Notes |
|---|---|---:|---|---|
| Backend | Remove admin bootstrap in `main.rs` | ⬜ |  |  |
| Backend | Add settings + setup tables migration | ⬜ |  |  |
| Backend | Add public system info endpoint | ⬜ |  |  |
| Backend | Add setup session claim/release | ⬜ |  |  |
| Backend | Implement SetupWriteGuard + local/remote policy | ⬜ |  |  |
| Backend | Add Tower rate limiting layer on `/setup/*` | ⬜ |  |  |
| Backend | Implement `/setup/config` | ⬜ |  |  |
| Backend | Implement `/setup/admin` + idempotency | ⬜ |  |  |
| Backend | Implement `/setup/libraries` + `/setup/paths/validate` | ⬜ |  |  |
| Backend | Implement `/setup/metadata` | ⬜ |  |  |
| Backend | Implement `/setup/network` | ⬜ |  |  |
| Backend | Implement `/setup/complete` | ⬜ |  |  |
| Backend | Implement `/setup/reset` (admin-only) | ⬜ |  |  |
| UI | Route guard (setup vs login) | ⬜ |  |  |
| UI | Wizard stepper UI + forms | ⬜ |  |  |
| Tests | Update integration tests for setup mode | ⬜ |  |  |
| Tests | Add e2e wizard tests | ⬜ |  |  |
| Hardening | Logging redaction + secret handling | ⬜ |  |  |
| Hardening | Concurrency: takeover/expiry correctness | ⬜ |  |  |

Legend: ⬜ not started, 🟧 in progress, ✅ done, 🟥 blocked

---

## 5) Phase checklists (in strict order)

### Phase 0 — Prep (spec compliance)
- [ ] Confirm the implementer has these files locally and will not improvise contracts:
  - `Rustyfin_Setup_Wizard_Spec_v4_OpenAPI_Sequence.md`
  - `rustyfin-setup-wizard.openapi.yaml`
- [ ] Confirm backend stack: Axum + Tower, SQLite via sqlx, JWT auth (already in repo).
- [ ] Decide rate limiting crate:
  - Prefer `tower-governor` (Tower layer).  
  - Any alternative MUST still be a Tower layer and MUST return 429 with the spec error body.

**Acceptance criteria**
- You can point at the OpenAPI YAML section for each endpoint you are about to implement.

---

### Phase 1 — Persistence + error model (foundation)

#### 1.1 DB migration
- [ ] Add `crates/db/migrations/003_settings_and_setup.sql` with:
  - [ ] `settings` table
  - [ ] `setup_session` table
  - [ ] `idempotency_keys` table
- [ ] Ensure migrations run in order on existing DBs (no destructive changes).

#### 1.2 DB repos
- [ ] Implement `repo/settings.rs` and export via `repo/mod.rs`.
- [ ] Implement `repo/setup_session.rs` (claim/release/refresh/purge expired).
- [ ] Implement `repo/idempotency.rs` (or equivalent).

#### 1.3 Core error model upgrades
- [ ] Extend `rustfin_core::error::ApiError` to support:
  - [ ] `UnprocessableEntity` (422) w/ field errors
  - [ ] `TooManyRequests` (429)
- [ ] Ensure the server returns the standard `{ "error": { "code", "message", "details" } }` envelope for these.

**Acceptance criteria**
- A failing validation returns HTTP 422 with field-level `details.fields`.
- A throttled request returns HTTP 429 with a stable error code.

---

### Phase 2 — Remove insecure bootstrap + add public setup detection

#### 2.1 Remove default admin bootstrap
- [ ] In `crates/server/src/main.rs`, remove:
  - `RUSTFIN_ADMIN_PASSWORD` fallback
  - `"admin"` creation on empty user table

#### 2.2 Ensure setup defaults exist
- [ ] On startup, ensure settings exist:
  - `setup_completed=false`
  - `setup_state=NotStarted`
  - `server_name="Rustyfin"` (or existing default)

#### 2.3 Add public setup endpoint
- [ ] Add `GET /api/v1/system/info/public` (unauthenticated), returning:
  - `setup_completed`, `setup_state`, `server_name`, `version`

**Acceptance criteria**
- Fresh DB: `/system/info/public` reports setup incomplete.
- Existing installs with existing users: server auto-migrates to `setup_completed=true` (per v4 rules) without breaking logins.

---

### Phase 3 — Setup session + guard + rate limiting

#### 3.1 Setup session endpoints
- [ ] Implement:
  - [ ] `POST /api/v1/setup/session/claim`
  - [ ] `POST /api/v1/setup/session/release`
- [ ] Enforce single active session with expiry refresh semantics.

#### 3.2 SetupWriteGuard
- [ ] Implement guard/extractor enforcing:
  - [ ] Owner token header required
  - [ ] Constant-time compare against stored hash
  - [ ] Correct local-vs-remote policy (trusted proxies safe)
  - [ ] Remote setup token requirement when remote setup enabled (and request is non-local)

#### 3.3 Rate limiting
- [ ] Add a Tower layer limiting:
  - [ ] per-IP
  - [ ] per-owner-token
- [ ] Ensure it is attached to `/api/v1/setup/*` write routes.

**Acceptance criteria**
- Missing/invalid owner token is rejected deterministically.
- Two browser sessions behave correctly (409 on second claim, expiry works).
- Bursty requests eventually yield 429 with correct error shape.

---

### Phase 4 — Implement setup endpoints (match OpenAPI order)

Implement endpoints exactly as defined in:
- `Rustyfin_Setup_Wizard_Spec_v4_OpenAPI_Sequence.md`
- `rustyfin-setup-wizard.openapi.yaml`

- [ ] `/setup/config` (GET + PUT)
- [ ] `/setup/admin` (POST + idempotency)
- [ ] `/setup/paths/validate` (POST)
- [ ] `/setup/libraries` (POST)
- [ ] `/setup/metadata` (GET + PUT)
- [ ] `/setup/network` (GET + PUT)
- [ ] `/setup/complete` (POST)
- [ ] `/setup/reset` (POST, admin-only)

**Acceptance criteria**
- Endpoints enforce state machine ordering with 409 `setup_state_violation`.
- Idempotency works for admin creation (replay returns same response; conflicts return 409).
- After completion, setup endpoints require admin (except `system/info/public`).

---

### Phase 5 — UI wizard (Next.js)

#### 5.1 Route guard
- [ ] On app boot, call `/api/v1/system/info/public`.
- [ ] If `setup_completed=false`, redirect to `/setup` and hide login.

#### 5.2 Wizard implementation
- [ ] Implement stepper with steps matching v4.
- [ ] Implement a dedicated API client for setup that:
  - [ ] does not require JWT
  - [ ] injects `X-Setup-Owner-Token`
  - [ ] displays field-level validation errors

**Acceptance criteria**
- Fresh install opens wizard, not login.
- Completing wizard routes to login and login succeeds.

---

### Phase 6 — Tests

#### 6.1 Backend tests
- [ ] Update integration tests to cover:
  - setup detection
  - session claim conflicts
  - state machine violations
  - idempotency
  - rate limiting
  - post-completion admin gating

#### 6.2 E2E tests (recommended)
- [ ] Add Playwright:
  - fresh install → wizard
  - finish wizard → login
  - skip libraries path
  - two clients race

**Acceptance criteria**
- CI can run tests deterministically (avoid timeouts by controlling session expiry in tests).

---

### Phase 7 — Hardening pass (don’t skip)

- [ ] Redact secrets in logs (passwords, owner token, remote token, library paths).
- [ ] Ensure forwarded headers are trusted only from configured proxies.
- [ ] Confirm config is resilient to partial progress + safe retries.
- [ ] Document “reset wizard” behavior and warnings in UI.

**Acceptance criteria**
- A threat-model skim finds no obvious “setup hijack” footguns.

---

## 6) “Definition of done” (final gate)

Mark this section only when everything below is true:

- [ ] Fresh install shows setup wizard; no login wall.
- [ ] No default admin credentials or bootstrap admin creation.
- [ ] All setup endpoints match OpenAPI YAML (request/response, status codes, errors).
- [ ] Setup write endpoints are guarded + rate limited.
- [ ] Concurrency behavior is correct (claim conflicts, expiry refresh).
- [ ] After completion, setup endpoints are admin-only.
- [ ] Automated tests cover the setup flow.
- [ ] Logs do not leak secrets or filesystem paths.

---

## 7) Notes / decision log

Use this section to record any **intentional** deviation from v4 (should be rare).

- 2026-02-13: (empty)
